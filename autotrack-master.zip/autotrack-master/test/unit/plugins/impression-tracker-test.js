// TODO(philipwalton): ensure `unobserveAllElements` doesn't error if called
// when no elements have yet been observed.
