// TODO(philipwalton): ensure multiple scroll events occurring before an
// event can be sent (idly) doesn't affect the data.
